export enum LoggerMessageType {
  LOG = 'log',
  WARN = 'WARN',
  ERROR = 'error',
}
