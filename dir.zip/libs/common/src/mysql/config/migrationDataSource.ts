// import { DataSource, DataSourceOptions } from 'typeorm';
// import { dbOptions } from '@database';
//
// export const AppDataSource = new DataSource(dbOptions as DataSourceOptions);
