import { AshlandLogEventDto } from './ashland-log-event.dto';

export class AshlandLogEvent {
  constructor(public readonly ashlandLogEventDto: AshlandLogEventDto) {}
}
