import { AshlandLogHandler } from './ashland-log/ashland-log.handler';

export const TaskEventHandlers = [AshlandLogHandler];
