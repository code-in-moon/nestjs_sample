export const GALLATIN_SERVICE = 'gallatin';
